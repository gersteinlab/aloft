#!/bin/bash

cp default.vatrc $HOME/.vatrc

echo cp default.vatrc $HOME/.vatrc
echo ----------------------------------------------------------------------
echo .vatrc has been added to your home directory
echo 
echo Add the following line to your .bashrc to complete install:
echo
echo export VAT_CONFIG_FILE=$HOME/.vatrc
echo ----------------------------------------------------------------------
